<?php
/**
 * REST API class for AFS Menu JSON endpoint.
 *
 * @package AFS_Menu
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * AFS_Menu_REST_API class.
 */
class AFS_Menu_REST_API {

	/**
	 * Namespace for REST API.
	 *
	 * @var string
	 */
	private $namespace = 'afs-menu/v1';

	/**
	 * Whether routes have been registered.
	 *
	 * @var bool
	 */
	private $routes_registered = false;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 */
	private function init_hooks() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ), 10 );
		
		// Also try to register immediately if REST API is already initialized.
		if ( did_action( 'rest_api_init' ) ) {
			$this->register_routes();
		}
	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes() {
		// Prevent duplicate registration.
		if ( $this->routes_registered ) {
			return;
		}

		// Test endpoint to verify API is working.
		register_rest_route(
			$this->namespace,
			'/test',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'test_endpoint' ),
				'permission_callback' => '__return_true',
			)
		);

		// Get menu endpoint.
		register_rest_route(
			$this->namespace,
			'/menus/(?P<menu_id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_menu_json' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'menu_id' => array(
						'required'          => true,
						'validate_callback' => array( $this, 'validate_menu_id' ),
					),
					'lang' => array(
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
						'default'           => $this->get_default_language(),
					),
					'currency' => array(
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
						'default'           => $this->get_default_currency(),
					),
				),
			)
		);

		$this->routes_registered = true;
	}

	/**
	 * Validate menu ID.
	 *
	 * @param int $menu_id Menu ID.
	 * @return bool
	 */
	public function validate_menu_id( $menu_id ) {
		return is_numeric( $menu_id ) && $menu_id > 0;
	}

	/**
	 * Get default language.
	 *
	 * @return string
	 */
	private function get_default_language() {
		if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
			return ICL_LANGUAGE_CODE;
		}
		return 'fr';
	}

	/**
	 * Get default currency.
	 *
	 * @return string
	 */
	private function get_default_currency() {
		if ( function_exists( 'get_woocommerce_currency' ) ) {
			return get_woocommerce_currency();
		}
		return 'EUR';
	}

	/**
	 * Test endpoint callback.
	 *
	 * @return WP_REST_Response
	 */
	public function test_endpoint() {
		return rest_ensure_response( array(
			'success' => true,
			'message' => 'AFS Menu REST API is working',
			'namespace' => $this->namespace,
		) );
	}

	/**
	 * Get menu JSON endpoint callback.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_menu_json( $request ) {
		$menu_id  = (int) $request->get_param( 'menu_id' );
		$lang     = sanitize_text_field( $request->get_param( 'lang' ) );
		$currency = strtoupper( sanitize_text_field( $request->get_param( 'currency' ) ) );

		// Check if menu exists.
		$menu = wp_get_nav_menu_object( $menu_id );
		if ( ! $menu || is_wp_error( $menu ) ) {
			// Return empty array instead of error to prevent breaking the UI
			return rest_ensure_response( array() );
		}

		// Check cache.
		$cache_key = $this->get_cache_key( $menu_id, $lang, $currency );
		$cached     = get_transient( $cache_key );

		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		try {
			// Set language if WPML is active.
			if ( function_exists( 'do_action' ) && defined( 'ICL_SITEPRESS_VERSION' ) ) {
				do_action( 'wpml_switch_language', $lang );
			}

			// Set currency if WCML is active.
			if ( defined( 'WCML_VERSION' ) && class_exists( 'WooCommerce' ) ) {
				$this->set_currency( $currency );
			}

			// Build menu JSON.
			$menu_json = $this->build_menu_json( $menu_id, $lang, $currency );

			// Cache the result for 1 hour.
			set_transient( $cache_key, $menu_json, HOUR_IN_SECONDS );

			return rest_ensure_response( $menu_json );
		} catch ( Exception $e ) {
			// Log error but return empty array to prevent breaking the UI
			error_log( 'AFS Menu API Error: ' . $e->getMessage() );
			return rest_ensure_response( array() );
		} catch ( Error $e ) {
			// Catch fatal errors in PHP 7+
			error_log( 'AFS Menu API Fatal Error: ' . $e->getMessage() );
			return rest_ensure_response( array() );
		}
	}

	/**
	 * Set currency for WCML.
	 *
	 * @param string $currency Currency code.
	 */
	private function set_currency( $currency ) {
		try {
			global $woocommerce_wpml;

			if ( ! $woocommerce_wpml || ! isset( $woocommerce_wpml->multi_currency ) ) {
				return;
			}

			$currency = strtoupper( $currency );
			$allowed_currencies = array( 'EUR', 'USD', 'GBP' );

			if ( ! in_array( $currency, $allowed_currencies, true ) ) {
				$currency = 'EUR';
			}

			// Set WCML client currency only if method exists
			if ( method_exists( $woocommerce_wpml->multi_currency, 'set_client_currency' ) ) {
				$woocommerce_wpml->multi_currency->set_client_currency( $currency );
			}

			// Also set cookie for consistency (only if headers not sent).
			if ( ! headers_sent() ) {
				setcookie( 'wcml_client_currency', $currency, time() + ( 86400 * 30 ), '/' );
			}
			$_COOKIE['wcml_client_currency'] = $currency;
		} catch ( Exception $e ) {
			// Silently fail - currency setting is not critical
			error_log( 'AFS Menu API: Error setting currency: ' . $e->getMessage() );
		}
	}

	/**
	 * Build menu JSON structure.
	 *
	 * @param int    $menu_id  Menu ID.
	 * @param string $lang     Language code.
	 * @param string $currency Currency code.
	 * @return array
	 */
	private function build_menu_json( $menu_id, $lang, $currency ) {
		// Check if function exists
		if ( ! function_exists( 'wp_get_nav_menu_items' ) ) {
			error_log( 'AFS Menu API: wp_get_nav_menu_items function not available' );
			return array();
		}

		// Get menu items.
		$menu_items = wp_get_nav_menu_items( $menu_id );

		if ( empty( $menu_items ) || is_wp_error( $menu_items ) ) {
			// Log if menu has no items
			if ( is_wp_error( $menu_items ) ) {
				error_log( 'AFS Menu API: Error getting menu items: ' . $menu_items->get_error_message() );
			}
			return array();
		}

		// Build menu tree (only top-level items).
		$top_level_items = array_filter( $menu_items, function( $item ) {
			return empty( $item->menu_item_parent ) || '0' === $item->menu_item_parent;
		} );

		if ( empty( $top_level_items ) ) {
			return array();
		}

		$menu_json = array();

		foreach ( $top_level_items as $item ) {
			$translated_item_id = $item->ID;
			$translated_item = null;
			
			try {
				// Translate menu item if WPML is active.
				$translated_item_id = $this->translate_menu_item_id( $item->ID, $lang );
				$translated_item     = function_exists( 'get_post' ) ? get_post( $translated_item_id ) : null;

				if ( ! $translated_item ) {
					// Try to use original item if translation fails
					$translated_item = $item;
					$translated_item_id = $item->ID;
				}
			} catch ( Exception $e ) {
				// Use original item if translation fails
				error_log( 'AFS Menu API: Error translating top-level item: ' . $e->getMessage() );
				$translated_item = $item;
				$translated_item_id = $item->ID;
			}

			// Get item title - try multiple sources
			$item_title = '';
			if ( $translated_item && isset( $translated_item->post_title ) && ! empty( $translated_item->post_title ) ) {
				$item_title = $translated_item->post_title;
			} elseif ( isset( $item->title ) && ! empty( $item->title ) ) {
				$item_title = $item->title;
			} elseif ( isset( $item->post_title ) && ! empty( $item->post_title ) ) {
				$item_title = $item->post_title;
			}

			// Skip if no title
			if ( empty( $item_title ) ) {
				continue;
			}

			// Get item data.
			$item_data = array(
				'name' => $item_title,
				'href' => isset( $item->url ) && ! empty( $item->url ) ? $item->url : '#',
			);

			// Get children (sublinks) - use original item ID for parent relationship.
			$children = $this->get_menu_item_children( $menu_items, $item->ID, $lang, $currency );
			
			// Always include sublinks array, even if empty (React expects it)
			$item_data['sublinks'] = is_array( $children ) ? $children : array();

			$menu_json[] = $item_data;
		}

		return $menu_json;
	}

	/**
	 * Translate menu item ID using WPML.
	 *
	 * @param int    $item_id Menu item ID.
	 * @param string $lang    Language code.
	 * @return int
	 */
	private function translate_menu_item_id( $item_id, $lang ) {
		try {
			if ( function_exists( 'apply_filters' ) && defined( 'ICL_SITEPRESS_VERSION' ) ) {
				$translated_id = apply_filters( 'wpml_object_id', $item_id, 'nav_menu_item', true, $lang );
				return $translated_id ?: $item_id;
			}
		} catch ( Exception $e ) {
			// If translation fails, return original ID
			error_log( 'AFS Menu API: Error translating menu item ID: ' . $e->getMessage() );
		}
		return $item_id;
	}

	/**
	 * Get menu item children (sublinks).
	 *
	 * @param array  $menu_items All menu items.
	 * @param int    $parent_id  Parent menu item ID.
	 * @param string $lang       Language code.
	 * @param string $currency   Currency code.
	 * @return array
	 */
	private function get_menu_item_children( $menu_items, $parent_id, $lang, $currency ) {
		$children = array();

		foreach ( $menu_items as $item ) {
			if ( (string) $item->menu_item_parent !== (string) $parent_id ) {
				continue;
			}

			$translated_item_id = $item->ID;
			$translated_item = null;

			try {
				// Translate menu item if WPML is active.
				$translated_item_id = $this->translate_menu_item_id( $item->ID, $lang );
				$translated_item     = function_exists( 'get_post' ) ? get_post( $translated_item_id ) : null;

				if ( ! $translated_item ) {
					// Try to use original item if translation fails
					$translated_item = $item;
					$translated_item_id = $item->ID;
				}
			} catch ( Exception $e ) {
				// Use original item if translation fails
				error_log( 'AFS Menu API: Error translating child item: ' . $e->getMessage() );
				$translated_item = $item;
				$translated_item_id = $item->ID;
			}

			// Get item title - try multiple sources
			$child_title = '';
			if ( $translated_item && isset( $translated_item->post_title ) && ! empty( $translated_item->post_title ) ) {
				$child_title = $translated_item->post_title;
			} elseif ( isset( $item->title ) && ! empty( $item->title ) ) {
				$child_title = $item->title;
			} elseif ( isset( $item->post_title ) && ! empty( $item->post_title ) ) {
				$child_title = $item->post_title;
			}

			// Skip if no title
			if ( empty( $child_title ) ) {
				continue;
			}

			$child_data = array(
				'name' => $child_title,
				'id'   => $translated_item_id,
				'url'  => isset( $item->url ) && ! empty( $item->url ) ? $item->url : null,
			);

			// Get buttons (only add if they exist).
			$button_one = $this->get_menu_item_button( $translated_item_id, 'one' );
			$button_two = $this->get_menu_item_button( $translated_item_id, 'two' );

			if ( $button_one ) {
				$child_data['button_one'] = $button_one;
			}

			if ( $button_two ) {
				$child_data['button_two'] = $button_two;
			}

			// Get products if show_products is enabled.
			$show_products = get_post_meta( $translated_item_id, '_show_products', true );
			if ( '1' === $show_products ) {
				$products = $this->load_products_data( $translated_item_id, $lang, $currency );
				// Always include products array, even if empty (React expects it)
				$child_data['products'] = is_array( $products ) ? $products : array();
			} else {
				// Always include products array, even if show_products is disabled
				$child_data['products'] = array();
			}

			$children[] = $child_data;
		}

		return $children;
	}

	/**
	 * Get menu item button data.
	 *
	 * @param int    $item_id Menu item ID.
	 * @param string $number Button number (one or two).
	 * @return array|null
	 */
	private function get_menu_item_button( $item_id, $number ) {
		$label = get_post_meta( $item_id, '_menu_item_button_' . $number . '_label', true );
		$url   = get_post_meta( $item_id, '_menu_item_button_' . $number . '_url', true );

		if ( empty( $label ) || empty( $url ) ) {
			return null;
		}

		return array(
			'label' => $label,
			'url'   => $url,
		);
	}

	/**
	 * Load products data for a menu item.
	 *
	 * @param int    $item_id  Menu item ID.
	 * @param string $lang     Language code.
	 * @param string $currency Currency code.
	 * @return array
	 */
	private function load_products_data( $item_id, $lang, $currency ) {
		// Check if WooCommerce is available.
		if ( ! function_exists( 'wc_get_product' ) || ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		// Get product IDs from meta.
		$menu_products_raw = get_post_meta( $item_id, '_menu_products', true );

		if ( empty( $menu_products_raw ) ) {
			return array();
		}

		// Parse product IDs.
		$product_ids = array_filter( array_map( 'trim', explode( ',', $menu_products_raw ) ) );

		if ( empty( $product_ids ) ) {
			return array();
		}

		// Translate product IDs if WPML is active.
		if ( function_exists( 'apply_filters' ) && defined( 'ICL_SITEPRESS_VERSION' ) ) {
			try {
				$translated_ids = array();
				foreach ( $product_ids as $product_id ) {
					if ( is_numeric( $product_id ) ) {
						$translated_id = apply_filters( 'wpml_object_id', (int) $product_id, 'product', true, $lang );
						if ( $translated_id ) {
							$translated_ids[] = $translated_id;
						}
					}
				}
				$product_ids = $translated_ids;
			} catch ( Exception $e ) {
				// If translation fails, use original IDs
				error_log( 'AFS Menu API: Error translating product IDs: ' . $e->getMessage() );
			}
		}

		// Limit to 12 products.
		$product_ids = array_slice( $product_ids, 0, 12 );

		// Load products.
		$products = array();

		foreach ( $product_ids as $product_id ) {
			try {
				$product = wc_get_product( $product_id );

				if ( ! $product || ! $product->is_visible() ) {
					continue;
				}

				// Get product image.
				$acf_image = function_exists( 'get_field' ) ? get_field( 'img', $product_id ) : null;
				$acf_image_url = $acf_image && isset( $acf_image['url'] ) ? $acf_image['url'] : '';
				$product_image_url = $acf_image_url ?: ( function_exists( 'wp_get_attachment_image_url' ) ? wp_get_attachment_image_url( $product->get_image_id(), 'full' ) : '' );

				// Get product price HTML (will be in the correct currency if WCML is active).
				$product_price = method_exists( $product, 'get_price_html' ) ? $product->get_price_html() : '';
				$product_name = method_exists( $product, 'get_name' ) ? $product->get_name() : get_the_title( $product_id );
				$product_url = function_exists( 'get_permalink' ) ? get_permalink( $product_id ) : '';

				$products[] = array(
					'name'  => $product_name,
					'price' => $product_price,
					'url'   => $product_url,
					'image' => $product_image_url ?: '',
				);
			} catch ( Exception $e ) {
				// Skip this product if there's an error
				error_log( 'AFS Menu API: Error loading product ' . $product_id . ': ' . $e->getMessage() );
				continue;
			}
		}

		return $products;
	}

	/**
	 * Get cache key.
	 *
	 * @param int    $menu_id  Menu ID.
	 * @param string $lang     Language code.
	 * @param string $currency Currency code.
	 * @return string
	 */
	private function get_cache_key( $menu_id, $lang, $currency ) {
		return 'afs_menu_json_' . $menu_id . '_' . $lang . '_' . strtoupper( $currency );
	}

	/**
	 * Invalidate cache for a menu.
	 *
	 * @param int $menu_id Menu ID.
	 */
	public static function invalidate_cache( $menu_id ) {
		// Invalidate for all possible language/currency combinations.
		$languages = array( 'fr', 'en' );
		$currencies = array( 'EUR', 'USD', 'GBP' );

		foreach ( $languages as $lang ) {
			foreach ( $currencies as $currency ) {
				$cache_key = 'afs_menu_json_' . $menu_id . '_' . $lang . '_' . $currency;
				delete_transient( $cache_key );
			}
		}
	}
}

